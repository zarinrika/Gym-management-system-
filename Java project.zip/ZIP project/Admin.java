import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admin {

    private JFrame frame;
    private JPanel panel;
    private JLabel welcomeLabel;
    private JButton addMemberButton;
    private JButton removeMemberButton;
    private JButton viewMembersButton;
    private JButton logoutButton;

    // Constructor to initialize the Admin Dashboard UI
    public Admin() {
        initializeFrame();
        initializePanel();
        initializeComponents();
        addComponentsToPanel();
        addActionListeners();
        finalizeFrame();
    }

    // Method to display the admin dashboard
    public static void displayAdminDashboard() {
        Admin admin = new Admin(); // Create an instance of Admin
        admin.frame.setVisible(true); // Use admin's frame instance
    }

    // Encapsulation: Initialize the JFrame
    private void initializeFrame() {
        frame = new JFrame("Admin Dashboard");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    // Encapsulation: Initialize the JPanel
    private void initializePanel() {
        panel = new JPanel() {
            // Overriding the paintComponent method to set a custom background
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Load and draw the background image
                ImageIcon backgroundIcon = new ImageIcon(ClassLoader.getSystemResource("image/admin.jpg"));
                Image backgroundImage = backgroundIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(null); // Using null layout for absolute positioning
        frame.add(panel);
    }

    // Encapsulation: Initialize the UI components
    private void initializeComponents() {
        welcomeLabel = new JLabel("Welcome Admin!");
        welcomeLabel.setBounds(50, 20, 300, 30);
        welcomeLabel.setForeground(Color.WHITE);

        addMemberButton = new JButton("Add Account");
        addMemberButton.setBounds(50, 70, 200, 50);
        addMemberButton.setBackground(new Color(0, 255, 200));
        addMemberButton.setForeground(Color.BLACK);

        removeMemberButton = new JButton("Delete Account");
        removeMemberButton.setBounds(50, 150, 200, 50);
        removeMemberButton.setBackground(new Color(0, 255, 200));
        removeMemberButton.setForeground(Color.BLACK);

        viewMembersButton = new JButton("View Members");
        viewMembersButton.setBounds(50, 230, 200, 50);
        viewMembersButton.setBackground(new Color(0, 255, 200));
        viewMembersButton.setForeground(Color.BLACK);

        logoutButton = new JButton("Logout");
        logoutButton.setBounds(300, 70, 200, 50);
        logoutButton.setBackground(new Color(0, 255, 200));
        logoutButton.setForeground(Color.BLACK);
    }

    // Encapsulation: Add components to the panel
    private void addComponentsToPanel() {
        panel.add(welcomeLabel);
        panel.add(addMemberButton);
        panel.add(removeMemberButton);
        panel.add(viewMembersButton);
        panel.add(logoutButton);
    }

    // Encapsulation: Add action listeners to buttons
    private void addActionListeners() {
        addMemberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                AddMember.displayAddMember(); // Redirect to the AddMember screen
            }
        });

        removeMemberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                DeleteMember.displayDeleteMember(); // Redirect to the DeleteMember screen
            }
        });

        viewMembersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                ViewMember.displayViewMembers("admin"); // Redirect to the ViewMembers screen
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the admin dashboard window
                JOptionPane.showMessageDialog(null, "Logged out successfully", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }

    // Encapsulation: Finalize the frame settings
    private void finalizeFrame() {
        frame.add(panel);
    }
}
