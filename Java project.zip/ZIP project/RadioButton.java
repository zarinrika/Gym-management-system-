import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class RoleSelectionFrame extends JFrame {
    private JRadioButton admin, manager, receptionist, trainer;
    
    public RoleSelectionFrame() {
        super("Select an Option");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.BLACK);
		
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/homepage.jpg"));
        Image image = i1.getImage();  // Get the image
        Image scaledImage = image.getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH); // Scale the image to window size
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage)); // Create a new label with the scaled image
        imageLabel.setBounds(0, 0, getWidth(), getHeight()); // Set bounds to match the window size
        add(imageLabel);  // Add the image label to the frame
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.BLACK);
        add(panel);
        
        Font font = new Font("Poppins", Font.PLAIN, 16);
        
        JLabel headline = new JLabel("Please choose an option:");
        headline.setFont(font);
        headline.setForeground(Color.WHITE);
        headline.setBounds(50, 20, 400, 40);
        panel.add(headline);
        
        int buttonWidth = 200, buttonHeight = 40, panelWidth = getWidth();
        
        admin = createRadioButton("Admin", font, (panelWidth - buttonWidth) / 2, 70, panel);
        manager = createRadioButton("Manager", font, (panelWidth - buttonWidth) / 2, 120, panel);
        receptionist = createRadioButton("Receptionist", font, (panelWidth - buttonWidth) / 2, 170, panel);
        trainer = createRadioButton("Trainer", font, (panelWidth - buttonWidth) / 2, 220, panel);
        
        ButtonGroup group = new ButtonGroup();
        group.add(admin);
        group.add(manager);
        group.add(receptionist);
        group.add(trainer);
        
        JButton nextButton = new JButton("Next");
        nextButton.setFont(font);
        nextButton.setBounds((panelWidth - 200) / 2, 300, 200, 50);
        nextButton.setBackground(new Color(0, 255, 200));
        nextButton.setForeground(Color.BLACK);
        panel.add(nextButton);
        
        nextButton.addActionListener(new ButtonClickListener());
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private JRadioButton createRadioButton(String text, Font font, int x, int y, JPanel panel) {
        JRadioButton radioButton = new JRadioButton(text);
        radioButton.setFont(font);
        radioButton.setForeground(Color.WHITE);
        radioButton.setBackground(Color.BLACK);
        radioButton.setBounds(x, y, 200, 40);
        panel.add(radioButton);
        return radioButton;
    }
    
    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (admin.isSelected()) {
                dispose();
                Login.displayLogin("Admin");
            } else if (manager.isSelected()) {
                dispose();
                Login.displayLogin("Manager");
            } else if (receptionist.isSelected()) {
                dispose();
                Login.displayLogin("Receptionist");
            } else if (trainer.isSelected()) {
                dispose();
                Login.displayLogin("Trainer");
            } else {
                JOptionPane.showMessageDialog(RoleSelectionFrame.this, "Please Select One Option!", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}

public class RadioButton {
    public static void main(String[] args) {
        new RoleSelectionFrame();
    }
}

