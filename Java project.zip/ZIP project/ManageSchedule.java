

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class ManageSchedule {
 
    private static JTextArea scheduleArea = new JTextArea();
 
    public static void displayManageSchedule() {
        JFrame frame = new JFrame("Manager Schedule Management");
        frame.setSize(700, 500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); 
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240)); 
        panel.setBounds(0, 0, 700, 500);
        frame.add(panel);
        panel.setLayout(null);
 
        JLabel welcomeLabel = new JLabel("Schedule Management");
        welcomeLabel.setBounds(50, 20, 300, 30);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(16.0f));  
        panel.add(welcomeLabel);
 
        scheduleArea.setEditable(false);  
        scheduleArea.setBounds(50, 50, 300, 150);  
        panel.add(scheduleArea);
 
        JButton viewScheduleButton = new JButton("View Schedule");
        viewScheduleButton.setBounds(50, 220, 150, 30);
        viewScheduleButton.setBackground(new Color(33, 150, 243)); 
        viewScheduleButton.setForeground(Color.WHITE);
        panel.add(viewScheduleButton);
 
        JButton addScheduleButton = new JButton("Add Schedule");
        addScheduleButton.setBounds(50, 270, 150, 30);
        addScheduleButton.setBackground(new Color(33, 150, 243)); 
        addScheduleButton.setForeground(Color.WHITE);
        panel.add(addScheduleButton);
 
        JButton removeScheduleButton = new JButton("Remove Schedule");
        removeScheduleButton.setBounds(50, 320, 150, 30);
        removeScheduleButton.setBackground(new Color(33, 150, 243)); 
        removeScheduleButton.setForeground(Color.WHITE);
        panel.add(removeScheduleButton);
 
        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 370, 150, 30);
        backButton.setBackground(new Color(33, 150, 243)); 
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);
 
        viewScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String currentSchedules = scheduleArea.getText();
                if (currentSchedules.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "No schedules found.", "Info", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Schedules are listed in the text area.", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
 
        addScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newSchedule = JOptionPane.showInputDialog(frame, "Enter Schedule Details:");
                if (newSchedule != null && !newSchedule.trim().isEmpty()) {
                    scheduleArea.append(newSchedule + "\n");
                    JOptionPane.showMessageDialog(frame, "Schedule added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter valid schedule details.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
 
        removeScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String scheduleToRemove = JOptionPane.showInputDialog(frame, "Enter Schedule to Remove:");
                if (scheduleToRemove != null && !scheduleToRemove.trim().isEmpty()) {
                    String currentSchedules = scheduleArea.getText();
                    if (currentSchedules.contains(scheduleToRemove)) {
                        String updatedSchedules = currentSchedules.replace(scheduleToRemove + "\n", "");
                        scheduleArea.setText(updatedSchedules);
                        JOptionPane.showMessageDialog(frame, "Schedule removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Schedule not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
 
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Admin.displayAdminDashboard();
            }
        });
 
        frame.setVisible(true);
    }
}