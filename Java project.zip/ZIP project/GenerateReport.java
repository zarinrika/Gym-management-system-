

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GenerateReport {
    static ArrayList<Member> members = new ArrayList<>();

    public static void displayReport() {
        JFrame frame = new JFrame("Generate Report");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(null);
        frame.add(panel);

        JButton reportButton = new JButton("Show Report");
        reportButton.setBounds(50, 50, 200, 30);
        reportButton.setBackground(new Color(33, 150, 243));
        reportButton.setForeground(Color.WHITE);
        panel.add(reportButton);

        reportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (members.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "No members registered yet!", "Info", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    StringBuilder report = new StringBuilder("Gym Members Report:\n\n");
                    for (Member member : members) {
                        report.append(member).append("\n");
                    }

                    JTextArea reportArea = new JTextArea(report.toString());
                    reportArea.setEditable(false);
                    JScrollPane scrollPane = new JScrollPane(reportArea);
                    scrollPane.setBounds(50, 100, 580, 300);
                    panel.add(scrollPane);
                    panel.revalidate();
                    panel.repaint();
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 420, 150, 30);
        backButton.setBackground(new Color(33, 150, 243));
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Admin.displayAdminDashboard();
            }
        });

        frame.setVisible(true);
    }
}

// Member Class
class Member {
    private final String name;
    private final String email;
    private final String phone;

    public Member(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Email: " + email + ", Phone: " + phone;
    }
}
