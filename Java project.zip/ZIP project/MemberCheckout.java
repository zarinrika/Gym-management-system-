

import javax.swing.*;
import java.io.*;

public class MemberCheckOut {
    private static final String MEMBER_FILE = "members.txt";

    public static void displayCheckOut() {  // Remove JFrame parentFrame parameter
        JFrame frame = new JFrame();
        
        JTextField memberIdField = new JTextField();
        Object[] message = { "Enter Member ID:", memberIdField };

        int option = JOptionPane.showConfirmDialog(frame, message, "Member Check-Out", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String memberId = memberIdField.getText().trim();
            if (memberId.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid Member ID", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (isValidMember(memberId)) {
                JOptionPane.showMessageDialog(frame, "Member Check-Out Successful!\nMember ID: " + memberId, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid Member ID or Membership Expired.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static boolean isValidMember(String memberId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(MEMBER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length >= 2 && details[0].trim().equals(memberId) && details[1].trim().equalsIgnoreCase("active")) {
                    return true; // Member exists and is active
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading member file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
}
