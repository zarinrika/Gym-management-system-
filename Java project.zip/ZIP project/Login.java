

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {
    private static String selectedRole;

    public static void displayLogin(String role) {
        selectedRole = role;

        JFrame frame = new JFrame("Gym Login Page");
        frame.setSize(700, 500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the background to black using a JPanel
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setBackground(Color.BLACK);
        backgroundPanel.setBounds(0, 0, 700, 500);
        backgroundPanel.setLayout(null);
        frame.add(backgroundPanel);

        // Panel for the login form, centered
        JPanel panel = new JPanel();
        panel.setBackground(new Color(34, 34, 34));
        panel.setBounds(190, 90, 320, 320);
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 5));
        backgroundPanel.add(panel);

        // Headline
        JLabel headline = new JLabel("Login to your Account");
        headline.setFont(new Font("Poppins", Font.BOLD, 16));
        headline.setForeground(Color.WHITE);
        headline.setBounds(50, 10, 200, 30);
        panel.add(headline);

        // Username Label
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setBounds(50, 50, 200, 20);
        panel.add(usernameLabel);

        // Username Text Field
        JTextField nameTextField = new JTextField();
        nameTextField.setBounds(50, 70, 200, 30);
        nameTextField.setBackground(new Color(50, 50, 50));
        nameTextField.setForeground(Color.WHITE);
        nameTextField.setCaretColor(Color.WHITE);
        nameTextField.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 255), 2));
        panel.add(nameTextField);

        // Password Label
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(50, 110, 200, 20);
        panel.add(passwordLabel);

        // Password Text Field
        JPasswordField passwordTextField = new JPasswordField();
        passwordTextField.setBounds(50, 130, 200, 30);
        passwordTextField.setBackground(new Color(50, 50, 50));
        passwordTextField.setForeground(Color.WHITE);
        passwordTextField.setCaretColor(Color.WHITE);
        passwordTextField.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 255), 2));
        panel.add(passwordTextField);

        // Remember Me checkbox
        JCheckBox rememberMeCheckBox = new JCheckBox("Remember me");
        rememberMeCheckBox.setBounds(50, 180, 120, 20);
        rememberMeCheckBox.setForeground(Color.WHITE);
        rememberMeCheckBox.setBackground(new Color(34, 34, 34));
        panel.add(rememberMeCheckBox);

        // Forgot Password label
        JLabel forgotPasswordLabel = new JLabel("Forgot Password?");
        forgotPasswordLabel.setBounds(180, 180, 120, 20);
        forgotPasswordLabel.setForeground(new Color(0, 150, 255));
        forgotPasswordLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.add(forgotPasswordLabel);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(50, 220, 200, 30);
        loginButton.setBackground(new Color(0, 255, 200));
        loginButton.setForeground(Color.BLACK);
        loginButton.setFocusPainted(false);
        panel.add(loginButton);

        // Action Listeners
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameTextField.getText().trim();
                    String password = new String(passwordTextField.getPassword()).trim();

                    if (name.isEmpty() || password.isEmpty()) {
                        throw new IllegalArgumentException("Username or Password cannot be empty!");
                    }

                    JOptionPane.showMessageDialog(frame, "Login Successful!\nName: " + name, "Successful", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                    navigateToDashboard();
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "An unexpected error occurred.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        forgotPasswordLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                JOptionPane.showMessageDialog(frame, "Check your email to reset your password.", "Forgot Password", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

   private static void navigateToDashboard() {
    try {
        if (selectedRole == null) {
            throw new IllegalStateException("Role selection is required!");
        }

        switch (selectedRole) {
            case "Admin":
                Admin.displayAdminDashboard();
                break;
            case "Manager":
                Manager.displayManagerDashboard();
                break;
            case "Receptionist":
                Receptionist.displayReceptionistDashboard();
                break;
            case "Trainer":
                Trainer.displayTrainerDashboard();
                break;
            default:
                throw new UnsupportedOperationException("No dashboard implemented for this role.");
        }
    } catch (IllegalStateException | UnsupportedOperationException ex) {
        JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "An unexpected error occurred while navigating.", "Error", JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
}
}
