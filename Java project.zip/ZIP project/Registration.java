

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
 
public class Registration {
 
    public static void displayRegistration() {
        JFrame frame = new JFrame("Gym Registration Page");
        frame.setSize(700, 500);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240)); 
        panel.setBounds(0, 0, 700, 500);
        frame.add(panel);
        panel.setLayout(null);
 
        JLabel headline = new JLabel("Create Your Account");
        headline.setFont(new Font("Poppins", Font.BOLD, 16));
        headline.setBounds(50, 20, 200, 30);
        panel.add(headline);
 
        JLabel nameLabel = new JLabel("User Name:");
        nameLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        nameLabel.setBounds(50, 50, 150, 30);
        panel.add(nameLabel);
 
        JTextField nameTextField = new JTextField();
        nameTextField.setBounds(200, 50, 200, 30);
        panel.add(nameTextField);
 
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        emailLabel.setBounds(50, 100, 150, 30);
        panel.add(emailLabel);
 
        JTextField emailTextField = new JTextField();
        emailTextField.setBounds(200, 100, 200, 30);
        panel.add(emailTextField);
 
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        passwordLabel.setBounds(50, 150, 100, 30);
        panel.add(passwordLabel);
 
        JPasswordField passwordTextField = new JPasswordField();
        passwordTextField.setBounds(200, 150, 200, 30);
        panel.add(passwordTextField);
 
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setFont(new Font("Poppins", Font.PLAIN, 14));
        confirmPasswordLabel.setBounds(50, 200, 150, 30);
        panel.add(confirmPasswordLabel);
        JLabel passwordHint = new JLabel("Password must be at least 6 characters long.");
        passwordHint.setFont(new Font("Poppins", Font.ITALIC, 12));
        passwordHint.setForeground(Color.GRAY);
        passwordHint.setBounds(200, 180, 250, 20);
        panel.add(passwordHint);
 
        JLabel requiredFieldHint = new JLabel("* Indicates a required field.");
        requiredFieldHint.setFont(new Font("Poppins", Font.ITALIC, 12));
        requiredFieldHint.setForeground(Color.RED);
        requiredFieldHint.setBounds(50, 280, 300, 20);
        panel.add(requiredFieldHint);
 
 
        JPasswordField confirmPasswordTextField = new JPasswordField();
        confirmPasswordTextField.setBounds(200, 200, 200, 30);
        panel.add(confirmPasswordTextField);
 
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(50, 250, 100, 30);
        registerButton.setBackground(new Color(33, 150, 243)); 
        registerButton.setForeground(Color.WHITE);
        panel.add(registerButton);
 
        JButton goBackButton = new JButton("Go Back");
        goBackButton.setBounds(350, 250, 100, 30);
        goBackButton.setBackground(new Color(33, 150, 243)); 
        goBackButton.setForeground(Color.WHITE);
        panel.add(goBackButton);
 
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameTextField.getText();
                String email = emailTextField.getText();
                String password = new String(passwordTextField.getPassword());
                String confirmPassword = new String(confirmPasswordTextField.getPassword());
 
                try {
                    if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                        throw new Exception("All fields must be filled!");
                    }
 
                    if (!email.contains("@") || !email.contains(".")) {
                        throw new Exception("Invalid email format!");
                    }
 
                    if (password.length() < 6) {
                        throw new Exception("Password must be at least 6 characters long!");
                    }
 
                    if (!password.equals(confirmPassword)) {
                        throw new Exception("Passwords do not match!");
                    }
 
                    try (FileWriter writer = new FileWriter("users.txt", true)) {
                        writer.write("Name: " + name + "\n");
                        writer.write("Email: " + email + "\n");
                        writer.write("Password: " + password + "\n\n");
                    }
 
                    JOptionPane.showMessageDialog(frame, "Registration Successful!\nName: " + name + "\nEmail: " + email, "Successful", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                    navigateToLogin();
 
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
 
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                RadioButton.main(new String[]{}); 
            }
        });
 
        frame.setVisible(true);
    }
 
    private static void navigateToLogin() {
        Login.displayLogin("Admin");  
    }
}