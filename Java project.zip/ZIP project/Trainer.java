import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Trainer {

    public static void displayTrainerDashboard() {
        JFrame frame = new JFrame("Trainer Dashboard");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize the panel first
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setBounds(0, 0, 700, 500);
        panel.setLayout(null); // Set layout to null for custom positioning
        frame.add(panel); // Add the panel to the frame

        // Set the background image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/trainer.jpg"));
        Image image = i1.getImage();  // Get the image
        Image scaledImage = image.getScaledInstance(700, 500, Image.SCALE_SMOOTH); // Scale the image to window size
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage)); // Create a new label with the scaled image
        imageLabel.setBounds(0, 0, 700, 500); // Set bounds to match the window size
        panel.add(imageLabel); // Add image to the panel

        // Add buttons to the panel (on top of the background image)
        JButton viewScheduleButton = new JButton("View Schedule");
        viewScheduleButton.setBounds(50, 50, 200, 30);
        viewScheduleButton.setBackground(new Color(33, 150, 243));
        viewScheduleButton.setForeground(Color.WHITE);
        panel.add(viewScheduleButton);

        JButton viewMembersButton = new JButton("View Assigned Members");
        viewMembersButton.setBounds(50, 100, 200, 30);
        viewMembersButton.setBackground(new Color(33, 150, 243));
        viewMembersButton.setForeground(Color.WHITE);
        panel.add(viewMembersButton);

        JButton trackProgressButton = new JButton("Track Member Progress");
        trackProgressButton.setBounds(50, 150, 200, 30);
        trackProgressButton.setBackground(new Color(33, 150, 243));
        trackProgressButton.setForeground(Color.WHITE);
        panel.add(trackProgressButton);

        JButton createWorkoutPlanButton = new JButton("Create Workout Plan");
        createWorkoutPlanButton.setBounds(50, 200, 200, 30);
        createWorkoutPlanButton.setBackground(new Color(33, 150, 243));
        createWorkoutPlanButton.setForeground(Color.WHITE);
        panel.add(createWorkoutPlanButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(50, 250, 200, 30);
        logoutButton.setBackground(new Color(33, 150, 243));
        logoutButton.setForeground(Color.WHITE);
        panel.add(logoutButton);

        // Action Listeners for buttons
        viewScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ViewSchedule.displaySchedule();
            }
        });

        viewMembersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "View Assigned Members feature is under construction.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        trackProgressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TrackMemberProgress.displayMemberProgress();
            }
        });

        createWorkoutPlanButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WorkoutPlanCreator.displayWorkoutPlan();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                JOptionPane.showMessageDialog(null, "Logged out successfully", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Make the frame visible
        frame.setVisible(true);
    }
}
