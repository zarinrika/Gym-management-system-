


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ViewSchedule {
    public static void displaySchedule() {
        JFrame scheduleFrame = new JFrame("Gym Schedule");
        scheduleFrame.setSize(700, 500);
        scheduleFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = {"Day", "Time", "Class", "Instructor"};
        Object[][] data = {
                {"Saturday", "7:00 AM - 8:00 AM", "Pushups", "A"},
                {"Sunday", "7:00 AM - 8:00 AM", "Yoga", "B"},
                {"Monday", "8:00 AM - 9:00 AM", "Strength Training", "C"},
                {"Tuesday", "8:00 AM - 9:00 AM", "Crunch", "D"},
        };

        JTable scheduleTable = new JTable(new DefaultTableModel(data, columnNames));
        JScrollPane scrollPane = new JScrollPane(scheduleTable);

        scheduleFrame.add(scrollPane, BorderLayout.CENTER);
        scheduleFrame.setVisible(true);
    }
}
