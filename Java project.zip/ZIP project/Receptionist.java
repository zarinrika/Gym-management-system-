import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Receptionist {

    public static void displayReceptionistDashboard() {
        JFrame frame = new JFrame("Receptionist Dashboard");
        frame.setSize(700, 500);  // Set to match the frame size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel and set its layout
        JPanel panel = new JPanel();
        panel.setLayout(null);  // Use null layout for absolute positioning
        frame.add(panel);

        // Set the background image to fill the entire panel
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/receptionist.jpg"));
        Image image = i1.getImage();  // Get the image
        Image scaledImage = image.getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH); // Scale the image
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage)); // Create a new label with the scaled image
        imageLabel.setBounds(0, 0, frame.getWidth(), frame.getHeight()); // Set bounds to match the window size
        panel.add(imageLabel);  // Add image to the panel

        // Column 1: Buttons for "Member Check-In", "Member Check-Out", and "Register Member"
        JButton checkInButton = new JButton("Member Check-In");
        checkInButton.setBounds(50, 70, 250, 50);  // Larger button size
        checkInButton.setBackground(new Color(0, 255, 200));
        checkInButton.setForeground(Color.BLACK);
        panel.add(checkInButton);

        JButton checkOutButton = new JButton("Member Check-Out");
        checkOutButton.setBounds(50, 150, 250, 50);
        checkOutButton.setBackground(new Color(0, 255, 200));
        checkOutButton.setForeground(Color.BLACK);
        panel.add(checkOutButton);

        JButton registerMemberButton = new JButton("Register Member");
        registerMemberButton.setBounds(50, 230, 250, 50);
        registerMemberButton.setBackground(new Color(0, 255, 200));
        registerMemberButton.setForeground(Color.BLACK);
        panel.add(registerMemberButton);

        // Column 2: Buttons for "Manage Payments", "Class Booking", and "Logout"
        JButton managePaymentsButton = new JButton("Manage Payments");
        managePaymentsButton.setBounds(350, 70, 250, 50);
        managePaymentsButton.setBackground(new Color(0, 255, 200));
        managePaymentsButton.setForeground(Color.BLACK);
        panel.add(managePaymentsButton);

        JButton classBookingButton = new JButton("Class Booking");
        classBookingButton.setBounds(350, 150, 250, 50);
        classBookingButton.setBackground(new Color(0, 255, 200));
        classBookingButton.setForeground(Color.BLACK);
        panel.add(classBookingButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(350, 230, 250, 50);
        logoutButton.setBackground(new Color(0, 255, 200));
        logoutButton.setForeground(Color.BLACK);
        panel.add(logoutButton);

        // Action Listeners
        checkInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MemberCheckIn.displayCheckIn();
            }
        });

        checkOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MemberCheckOut.displayCheckOut();
            }
        });

        registerMemberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Registration.displayRegistration();
            }
        });

        managePaymentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Payment.showPaymentUI();
            }
        });

        classBookingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Class Booking feature is under construction.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                JOptionPane.showMessageDialog(null, "Logged out successfully", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
