

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class AddMember {
    static ArrayList<String> members = new ArrayList<>();

    public static void displayAddMember() {
        JFrame frame = new JFrame("Add Member");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(null);
        frame.add(panel);

        JLabel nameLabel = new JLabel("Enter Member Name:");
        nameLabel.setBounds(50, 50, 200, 30);
        panel.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(50, 80, 200, 30);
        panel.add(nameField);

        JButton addButton = new JButton("Add");
        addButton.setBounds(50, 120, 150, 30);
        addButton.setBackground(new Color(33, 150, 243));
        addButton.setForeground(Color.WHITE);
        panel.add(addButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                if (!name.isEmpty()) {
                    members.add(name);
                    JOptionPane.showMessageDialog(frame, "Member added successfully!");
                    nameField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter a name.");
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 160, 150, 30);
        backButton.setBackground(new Color(33, 150, 243));
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Admin.displayAdminDashboard();
            }
        });

        frame.setVisible(true);
    }
}
