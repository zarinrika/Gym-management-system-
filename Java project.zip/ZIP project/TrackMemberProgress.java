

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TrackMemberProgress {
    public static void displayMemberProgress() {
        JFrame frame = new JFrame("Track Member Progress");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel titleLabel = new JLabel("Track Member Progress");
        titleLabel.setBounds(50, 20, 300, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        frame.add(titleLabel);

        JLabel memberNameLabel = new JLabel("Name:");
        memberNameLabel.setBounds(50, 60, 100, 30);
        frame.add(memberNameLabel);

        JTextField memberNameField = new JTextField();
        memberNameField.setBounds(150, 60, 200, 30);
        frame.add(memberNameField);

        JLabel weightLabel = new JLabel("Weight (kg):");
        weightLabel.setBounds(50, 100, 100, 30);
        frame.add(weightLabel);

        JTextField weightField = new JTextField();
        weightField.setBounds(150, 100, 200, 30);
        frame.add(weightField);

        JLabel bmiLabel = new JLabel("BMI:");
        bmiLabel.setBounds(50, 140, 100, 30);
        frame.add(bmiLabel);

        JTextField bmiField = new JTextField();
        bmiField.setBounds(150, 140, 200, 30);
        frame.add(bmiField);

        JButton addProgressButton = new JButton("Add Progress");
        addProgressButton.setBounds(150, 180, 150, 30);
        frame.add(addProgressButton);

        String[] columnNames = {"Name", "Weight (kg)", "BMI"};
        DefaultTableModel progressTableModel = new DefaultTableModel(columnNames, 0);
        JTable progressTable = new JTable(progressTableModel);
        JScrollPane progressScrollPane = new JScrollPane(progressTable);
        progressScrollPane.setBounds(50, 230, 500, 300);
        frame.add(progressScrollPane);

        addProgressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberName = memberNameField.getText();
                String weight = weightField.getText();
                String bmi = bmiField.getText();

                if (memberName.isEmpty() || weight.isEmpty() || bmi.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    progressTableModel.addRow(new Object[]{memberName, weight, bmi});
                    memberNameField.setText("");
                    weightField.setText("");
                    bmiField.setText("");
                    JOptionPane.showMessageDialog(frame, "Progress added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        frame.setVisible(true);
    }
}
