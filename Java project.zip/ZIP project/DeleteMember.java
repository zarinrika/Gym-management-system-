

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteMember {

    public static void displayDeleteMember() {
        JFrame frame = new JFrame("Delete Member");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(null);
        frame.add(panel);

        JLabel titleLabel = new JLabel("Delete Member");
        titleLabel.setBounds(50, 20, 200, 30);
        titleLabel.setFont(titleLabel.getFont().deriveFont(16.0f));
        panel.add(titleLabel);

        JLabel nameLabel = new JLabel("Enter Member Name to Delete:");
        nameLabel.setBounds(50, 70, 250, 30);
        panel.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(50, 100, 200, 30);
        panel.add(nameField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(50, 150, 150, 30);
        deleteButton.setBackground(new Color(33, 150, 243));
        deleteButton.setForeground(Color.WHITE);
        panel.add(deleteButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 200, 150, 30);  // Adjusted position
        backButton.setBackground(new Color(33, 150, 243));
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberName = nameField.getText();
                if (AddMember.members.contains(memberName)) {
                    AddMember.members.remove(memberName); 
                    JOptionPane.showMessageDialog(frame, "Member deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    nameField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Member not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Admin.displayAdminDashboard(); 
            }
        });

        frame.setVisible(true);
    }
}
