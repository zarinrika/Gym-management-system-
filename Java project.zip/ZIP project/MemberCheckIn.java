

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MemberCheckIn {
    private static final String MEMBER_FILE = "members.txt"; // Stores member details
    private static final String CHECKIN_FILE = "check_ins.txt"; // Stores check-in logs

    public static void displayCheckIn() {
        JFrame frame = new JFrame("Member Check-In");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(null);
        frame.add(panel);

        JLabel idLabel = new JLabel("Enter Member ID:");
        idLabel.setBounds(50, 50, 200, 30);
        panel.add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(50, 80, 200, 30);
        panel.add(idField);

        JButton checkInButton = new JButton("Check In");
        checkInButton.setBounds(50, 120, 150, 30);
        checkInButton.setBackground(new Color(33, 150, 243));
        checkInButton.setForeground(Color.WHITE);
        panel.add(checkInButton);

        checkInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String memberIdStr = idField.getText().trim();
                if (!memberIdStr.isEmpty()) {
                    try {
                        int memberId = Integer.parseInt(memberIdStr);
                        if (isValidMember(memberId)) {
                            recordCheckIn(memberId);
                            JOptionPane.showMessageDialog(frame, "Check-in successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                            idField.setText("");
                        } else {
                            JOptionPane.showMessageDialog(frame, "Invalid Member ID or Membership Expired.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter a valid numeric Member ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Member ID cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 160, 150, 30);
        backButton.setBackground(new Color(33, 150, 243));
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Receptionist.displayReceptionistDashboard();
            }
        });

        frame.setVisible(true);
    }

    private static boolean isValidMember(int memberId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(MEMBER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length >= 2) {
                    int id = Integer.parseInt(details[0].trim());
                    String status = details[1].trim();
                    if (id == memberId && status.equalsIgnoreCase("active")) {
                        return true; // Member exists and is active
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error reading member file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    private static void recordCheckIn(int memberId) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CHECKIN_FILE, true))) {
            writer.write(memberId + "," + timestamp);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error recording check-in: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
