

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewMember {
    public static void displayViewMembers(String userType) {
        JFrame frame = new JFrame("View Members");
        frame.setSize(700, 500);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(null);
        frame.add(panel);

        JLabel titleLabel = new JLabel("Member List:");
        titleLabel.setBounds(50, 20, 200, 30);
        titleLabel.setFont(titleLabel.getFont().deriveFont(16.0f));
        panel.add(titleLabel);

        ArrayList<String> members = AddMember.members != null ? AddMember.members : new ArrayList<>();
        members.add("Zarin RIka");
        members.add("Zarin Tasnim");

        int y = 70;
        for (String member : members) {
            JLabel memberLabel = new JLabel(member);
            memberLabel.setBounds(50, y, 300, 30);
            panel.add(memberLabel);
            y += 40;
        }

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 400, 150, 30);
        backButton.setBackground(new Color(33, 150, 243));
        backButton.setForeground(Color.WHITE);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                if (userType.equals("manager")) {
                    Manager.displayManagerDashboard();
                } else if (userType.equals("admin")) {
                    Admin.displayAdminDashboard();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid user type!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.setVisible(true);
    }
}
