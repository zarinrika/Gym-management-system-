
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WorkoutPlanCreator {
    public static void displayWorkoutPlan() {
        JFrame frame = new JFrame("Create Workout Plan");
        frame.setSize(600, 500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel exerciseLabel = new JLabel("Exercise:");
        exerciseLabel.setBounds(50, 50, 100, 30);
        frame.add(exerciseLabel);

        JTextField exerciseField = new JTextField();
        exerciseField.setBounds(150, 50, 200, 30);
        frame.add(exerciseField);

        JLabel setsLabel = new JLabel("Sets:");
        setsLabel.setBounds(50, 100, 100, 30);
        frame.add(setsLabel);

        JTextField setsField = new JTextField();
        setsField.setBounds(150, 100, 200, 30);
        frame.add(setsField);

        JLabel repsLabel = new JLabel("Reps:");
        repsLabel.setBounds(50, 150, 100, 30);
        frame.add(repsLabel);

        JTextField repsField = new JTextField();
        repsField.setBounds(150, 150, 200, 30);
        frame.add(repsField);

        JLabel durationLabel = new JLabel("Duration (mins):");
        durationLabel.setBounds(50, 200, 100, 30);
        frame.add(durationLabel);

        JTextField durationField = new JTextField();
        durationField.setBounds(150, 200, 200, 30);
        frame.add(durationField);

        JButton addButton = new JButton("Add to Plan");
        addButton.setBounds(150, 250, 150, 30);
        frame.add(addButton);

        String[] columnNames = {"Exercise", "Sets", "Reps", "Duration"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable workoutTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(workoutTable);
        scrollPane.setBounds(50, 300, 500, 150);
        frame.add(scrollPane);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String exercise = exerciseField.getText();
                String sets = setsField.getText();
                String reps = repsField.getText();
                String duration = durationField.getText();

                if (exercise.isEmpty() || sets.isEmpty() || reps.isEmpty() || duration.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    tableModel.addRow(new Object[]{exercise, sets, reps, duration});

                    exerciseField.setText("");
                    setsField.setText("");
                    repsField.setText("");
                    durationField.setText("");
                }
            }
        });

        frame.setVisible(true);
    }
}
