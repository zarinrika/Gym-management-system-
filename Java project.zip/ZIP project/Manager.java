

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Manager {

    public static void displayManagerDashboard() {
        JFrame frame = new JFrame("Manager Dashboard");

        frame.setSize(700, 500);  // Frame size

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.BLACK);  // Set background color to black
        panel.setLayout(null);  // Use null layout for absolute positioning
        frame.add(panel);

        // Set the background image to fill the entire frame
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("image/manager.jpg"));
        Image image = i1.getImage();  // Get the image
        Image scaledImage = image.getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH); // Scale the image to fit the frame size
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage)); // Create a new label with the scaled image
        imageLabel.setBounds(0, 0, frame.getWidth(), frame.getHeight()); // Set bounds to match the window size
        panel.add(imageLabel);  // Add image to the panel

        // Column 1: Buttons for "Manage Schedule", "View Members", "Generate Reports"
        JButton manageScheduleButton = new JButton("Manage Schedule");
        manageScheduleButton.setBounds(50, 70, 200, 50);  // Larger button size
        manageScheduleButton.setBackground(new Color(0, 255, 200));  // Set button color
        manageScheduleButton.setForeground(Color.BLACK);  // Set text color to black
        panel.add(manageScheduleButton);

        JButton viewMembersButton = new JButton("View Members");
        viewMembersButton.setBounds(50, 150, 200, 50);
        viewMembersButton.setBackground(new Color(0, 255, 200));
        viewMembersButton.setForeground(Color.BLACK);
        panel.add(viewMembersButton);

        JButton generateReportsButton = new JButton("Generate Reports");
        generateReportsButton.setBounds(50, 230, 200, 50);
        generateReportsButton.setBackground(new Color(0, 255, 200));
        generateReportsButton.setForeground(Color.BLACK);
        panel.add(generateReportsButton);

        // Column 2: Button for "Logout"
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(300, 70, 200, 50);  // Larger button size, in second column
        logoutButton.setBackground(new Color(0, 255, 200));
        logoutButton.setForeground(Color.BLACK);
        panel.add(logoutButton);

        // Action listeners for each button
        manageScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                ManageSchedule.displayManageSchedule();
            }
        });

        viewMembersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                ViewMember.displayViewMembers("manager");
            }
        });

        generateReportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GenerateReport.displayReport();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                JOptionPane.showMessageDialog(null, "Logged out successfully", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        frame.setLocationRelativeTo(null);  // Center the window

        frame.setVisible(true);
    }
}
