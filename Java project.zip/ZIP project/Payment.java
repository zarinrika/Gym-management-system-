import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Payment {

    private JFrame frame;
    private JTextField paymentIdField;
    private JTextField payerNameField;
    private JTextField amountField;
    private JTextField dateField;
    private JTextArea displayArea;
    private ArrayList<String> paymentList;

    public Payment() { 
        paymentList = new ArrayList<>();
    }

    public void initializeUI() {
        frame = new JFrame("Payment Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel paymentIdLabel = new JLabel("Payment ID:");
        paymentIdField = new JTextField();
        JLabel payerNameLabel = new JLabel("Payer Name:");
        payerNameField = new JTextField();
        JLabel amountLabel = new JLabel("Amount:");
        amountField = new JTextField();
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateField = new JTextField();

        inputPanel.add(paymentIdLabel);
        inputPanel.add(paymentIdField);
        inputPanel.add(payerNameLabel);
        inputPanel.add(payerNameField);
        inputPanel.add(amountLabel);
        inputPanel.add(amountField);
        inputPanel.add(dateLabel);
        inputPanel.add(dateField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Add Payment");
        JButton viewButton = new JButton("View Payments");
        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPayment();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewPayments();
            }
        });

        frame.setVisible(true);
    }

    private void addPayment() {
        String paymentId = paymentIdField.getText().trim();
        String payerName = payerNameField.getText().trim();
        String amountText = amountField.getText().trim();
        String date = dateField.getText().trim();

        if (paymentId.isEmpty() || payerName.isEmpty() || amountText.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double amount = Double.parseDouble(amountText);
            String paymentRecord = "ID: " + paymentId + ", Name: " + payerName + ", Amount: " + amount + ", Date: " + date;
            paymentList.add(paymentRecord);
            JOptionPane.showMessageDialog(frame, "Payment added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            paymentIdField.setText("");
            payerNameField.setText("");
            amountField.setText("");
            dateField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Amount must be a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewPayments() {
        if (paymentList.isEmpty()) {
            displayArea.setText("No payments available.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (String payment : paymentList) {
                sb.append(payment).append("\n");
            }
            displayArea.setText(sb.toString());
        }
    }

    // Add a static method to create an instance and call initializeUI()
    public static void showPaymentUI() {
        new Payment().initializeUI();
    }
}
